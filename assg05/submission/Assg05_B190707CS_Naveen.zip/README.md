# Implement Bellman - Ford algorithm for DVR and Dijkstra algorithm for LSR

DVR - Distance Vector Routing
LSR - Link State Routing

dvr.c - DVR implementation
lsr.c - LSR implementtaion

dvr.png - DVR output screen
lsr.png - LSR output screen
